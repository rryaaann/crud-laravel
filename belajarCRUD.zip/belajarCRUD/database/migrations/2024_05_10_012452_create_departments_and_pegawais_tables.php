<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDepartmentsAndPegawaisTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Membuat tabel departments
        Schema::create('departments', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->timestamps();
        });

        // Membuat tabel pegawais dengan kolom department_id
        Schema::create('pegawais', function (Blueprint $table) {
            $table->id();
            $table->string('nama');
            $table->string('jabatan');
            $table->unsignedInteger('umur');
            $table->string('alamat');
            $table->unsignedBigInteger('department_id')->nullable();
            $table->timestamps();

            // Menambahkan foreign key constraint untuk kolom department_id
            $table->foreign('department_id')->references('id')->on('departments')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Menghapus foreign key constraint dari kolom department_id di tabel pegawais
        Schema::table('pegawais', function (Blueprint $table) {
            $table->dropForeign(['department_id']);
        });

        // Menghapus tabel pegawais dan departments
        Schema::dropIfExists('pegawais');
        Schema::dropIfExists('departments');
    }
}
