

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Edit Pegawai</h1>
        <<form action="<?php echo e(route('pegawai.update', $pegawai->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="nama">Nama Pegawai:</label>
                <input type="text" name="nama" class="form-control" value="<?php echo e($pegawai->nama); ?>">
            </div>
            <div class="form-group">
                <label for="jabatan">Jabatan:</label>
                <input type="text" name="jabatan" class="form-control" value="<?php echo e($pegawai->jabatan); ?>">
            </div>
            <div class="form-group">
                <label for="umur">Umur:</label>
                <input type="number" name="umur" class="form-control" value="<?php echo e($pegawai->umur); ?>">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <textarea name="alamat" class="form-control"><?php echo e($pegawai->alamat); ?></textarea>
            </div>
            <div class="form-group">
                <label for="department_id">Departemen:</label>
                <select name="department_id" class="form-control">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>" <?php echo e($pegawai->department_id == $department->id ? 'selected' : ''); ?>><?php echo e($department->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
        <a href="<?php echo e(route('pegawai.show', $pegawai->id)); ?>" class="btn btn-secondary">Batal</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views/pegawais/edit.blade.php ENDPATH**/ ?>