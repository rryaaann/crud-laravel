

<?php $__env->startSection('content'); ?>
    <h1>Detail Departemen</h1>
    <p><strong>Nama:</strong> <?php echo e($department->name); ?></p>
    <a href="<?php echo e(route('departments.edit', $department->id)); ?>" class="btn btn-primary">Edit</a>
    <form action="<?php echo e(route('departments.destroy', $department->id)); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus?')">Hapus</button>
    </form>
    <a href="<?php echo e(route('departments.index')); ?>" class="btn btn-secondary">Kembali ke Daftar Departemen</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views/departments/show.blade.php ENDPATH**/ ?>