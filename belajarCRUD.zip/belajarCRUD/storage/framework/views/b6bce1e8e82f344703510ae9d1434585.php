<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pegawai Baru</title>
</head>
<body>
 
    <h2>Tambah Pegawai Baru</h2>
 
    <form action="/pegawais/store" method="post">
        <?php echo e(csrf_field()); ?>

        <label for="nama">Nama:</label><br>
        <input type="text" id="nama" name="nama"><br>
        <label for="jabatan">Jabatan:</label><br>
        <input type="text" id="jabatan" name="jabatan"><br>
        <label for="umur">Umur:</label><br>
        <input type="number" id="umur" name="umur"><br>
        <label for="alamat">Alamat:</label><br>
        <textarea id="alamat" name="alamat"></textarea><br><br>
        <button type="submit">Simpan</button>
    </form>
 
</body>
</html>
<?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views\tambah_pegawai.blade.php ENDPATH**/ ?>