

<?php $__env->startSection('content'); ?>
    <h1>Daftar Departemen</h1>
    <a href="<?php echo e(route('departments.create')); ?>" class="btn btn-primary mb-3">Tambah Departemen</a>

    <ul class="list-group">
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
                <?php echo e($department->name); ?>

                <span class="float-right">
                    <a href="<?php echo e(route('departments.show', $department->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                    <a href="<?php echo e(route('departments.edit', $department->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views/departments/index.blade.php ENDPATH**/ ?>