

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Detail Pegawai</h1>
        <div class="card">
            <div class="card-header">
                <?php echo e($pegawai->nama); ?>

            </div>
            <div class="card-body">
                <p>Jabatan: <?php echo e($pegawai->jabatan); ?></p>
                <p>Umur: <?php echo e($pegawai->umur); ?></p>
                <p>Alamat: <?php echo e($pegawai->alamat); ?></p>
                <?php if($pegawai->department): ?>
                    <p>Department: <?php echo e($pegawai->department->name); ?></p>
                <?php else: ?>
                    <p>Department: Belum memiliki departemen</p>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(route('pegawai.edit', $pegawai->id)); ?>" class="btn btn-primary">Edit</a>
                <form action="<?php echo e(route('pegawai.destroy', $pegawai->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus pegawai ini?')">Hapus</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views/pegawais/show.blade.php ENDPATH**/ ?>