<!DOCTYPE html>
<html>
<head>
    <title>Tutorial Membuat CRUD Pada Laravel - www.malasngoding.com</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        h3 {
            color: #555;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f5f5f5;
            color: #333;
        }
        tr:hover {
            background-color: #f2f2f2;
        }
        .btn {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
 
    <div class="container">
        <h2>MUHAMAD ARIANTO NIM 221240001281</h2>
        <h3>Data Pegawai</h3>
     
        <a href="/pegawais/tambah" class="btn">+ Tambah Pegawai Baru</a>
        
        <br/><br/>
     
        <table>
            <tr>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Umur</th>
                <th>Alamat</th>
                <th>Opsi</th>
            </tr>
            <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pegawai->nama); ?></td>
                <td><?php echo e($pegawai->jabatan); ?></td>
                <td><?php echo e($pegawai->umur); ?></td>
                <td><?php echo e($pegawai->alamat); ?></td>
                <td>
                    <a href="/pegawais/edit<?php echo e($pegawai->id); ?>" class="btn">Edit</a>
                    <form id="form-delete-<?php echo e($pegawai->id); ?>" action="/pegawais/hapus/<?php echo e($pegawai->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus pegawai ini?')">Hapus</button>
</form>
</form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
 
</body>
</html>
<?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views/index.blade.php ENDPATH**/ ?>