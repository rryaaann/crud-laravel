

<?php $__env->startSection('content'); ?>
    <h1>Edit Departemen</h1>
    <form action="<?php echo e(route('departments.update', $department->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Nama Departemen:</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($department->name); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
    <a href="<?php echo e(route('departments.show', $department->id)); ?>" class="btn btn-secondary">Batal</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views/departments/edit.blade.php ENDPATH**/ ?>