

<?php $__env->startSection('content'); ?>
    <h1>Buat Departemen Baru</h1>
    <form action="<?php echo e(route('departments.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Nama Departemen:</label>
            <input type="text" name="name" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views/departments/create.blade.php ENDPATH**/ ?>