

<?php $__env->startSection('content'); ?>
    <h1>Daftar Pegawai</h1>
    <a href="<?php echo e(route('pegawai.create')); ?>" class="btn btn-primary mb-3">Tambah Pegawai</a>

    <ul class="list-group">
        <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
                <?php echo e($pegawai->nama); ?>

                <?php if($pegawai->department): ?>
                    - <?php echo e($pegawai->department->name); ?>

                <?php else: ?>
                    - Belum memiliki departemen
                <?php endif; ?>
                <span class="float-right">
                    <a href="<?php echo e(route('pegawai.show', $pegawai->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                    <a href="<?php echo e(route('pegawai.edit', $pegawai->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\indot\OneDrive\Desktop\tugas\tugas_uts\tugas_p-web\belajarCRUD\resources\views/pegawais/index.blade.php ENDPATH**/ ?>