<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Department;

class DepartmentController extends Controller
{
    // Menampilkan daftar departemen
    public function index()
    {
        $departments = Department::all();
        return view('departments.index', compact('departments'));
    }

    // Menampilkan formulir pembuatan departemen baru
    public function create()
    {
        return view('departments.create');
    }

    // Menyimpan departemen baru ke database
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        Department::create($request->all());

        return redirect()->route('departments.index')->with('success', 'Department created successfully.');
    }

    // Menampilkan formulir untuk mengedit departemen
    public function edit($id)
    {
        $department = Department::findOrFail($id);
        return view('departments.edit', compact('department'));
    }

    // Mengupdate departemen yang ada di database
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $department = Department::findOrFail($id);
        $department->update($request->all());

        return redirect()->route('departments.index')->with('success', 'Department updated successfully.');
    }

    // Menampilkan detail departemen
public function show($id)
{
    $department = Department::findOrFail($id);
    return view('departments.show', compact('department'));
}

    // Menghapus departemen dari database
    public function destroy($id)
    {
        $department = Department::findOrFail($id);
        $department->delete();

        return redirect()->route('departments.index')->with('success', 'Department deleted successfully.');
    }
}
