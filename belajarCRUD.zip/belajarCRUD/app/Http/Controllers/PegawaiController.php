<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pegawai;
use App\Models\Department;

class PegawaiController extends Controller
{
    // Menampilkan daftar pegawai
    public function index()
    {
        $pegawais = Pegawai::all();
        return view('pegawais.index', compact('pegawais'));
    }

    // Menampilkan formulir pembuatan pegawai baru
    public function create()
    {
        $departments = Department::all();
        return view('pegawais.create', compact('departments'));
    }

    // Menyimpan pegawai baru ke database
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255',
            'umur' => 'required|integer',
            'alamat' => 'required|string|max:255',
            'department_id' => 'nullable|exists:departments,id',
        ]);

        Pegawai::create($request->all());

        return redirect()->route('pegawais.index')->with('success', 'Pegawai created successfully.');
    }

    // Menampilkan formulir untuk mengedit pegawai
    public function edit($id)
    {
        $pegawai = Pegawai::findOrFail($id);
        $departments = Department::all();
        return view('pegawais.edit', compact('pegawai', 'departments'));
    }

    // Mengupdate pegawai yang ada di database
    public function update(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255',
            'umur' => 'required|integer',
            'alamat' => 'required|string|max:255',
            'department_id' => 'nullable|exists:departments,id',
        ]);

        $pegawai = Pegawai::findOrFail($id);
        $pegawai->update($request->all());

        return redirect()->route('pegawais.index')->with('success', 'Pegawai updated successfully.');
    }
    public function show($id)
    {
        $pegawai = Pegawai::findOrFail($id);
        return view('pegawais.show', compact('pegawai'));
    }
    // Menghapus pegawai dari database
    public function destroy($id)
    {
        $pegawai = Pegawai::findOrFail($id);
        $pegawai->delete();

        return redirect()->route('pegawais.index')->with('success', 'Pegawai deleted successfully.');
    }
}
