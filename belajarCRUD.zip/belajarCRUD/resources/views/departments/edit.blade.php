@extends('layouts.app')

@section('content')
    <h1>Edit Departemen</h1>
    <form action="{{ route('departments.update', $department->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="name">Nama Departemen:</label>
            <input type="text" name="name" class="form-control" value="{{ $department->name }}">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
    <a href="{{ route('departments.show', $department->id) }}" class="btn btn-secondary">Batal</a>
@endsection
