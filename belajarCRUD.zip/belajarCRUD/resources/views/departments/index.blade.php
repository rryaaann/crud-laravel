@extends('layouts.app')

@section('content')
    <h1>Daftar Departemen</h1>
    <a href="{{ route('departments.create') }}" class="btn btn-primary mb-3">Tambah Departemen</a>

    <ul class="list-group">
        @foreach ($departments as $department)
            <li class="list-group-item">
                {{ $department->name }}
                <span class="float-right">
                    <a href="{{ route('departments.show', $department->id) }}" class="btn btn-info btn-sm">Detail</a>
                    <a href="{{ route('departments.edit', $department->id) }}" class="btn btn-primary btn-sm">Edit</a>
                </span>
            </li>
        @endforeach
    </ul>
@endsection
