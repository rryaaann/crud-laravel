@extends('layouts.app')

@section('content')
    <h1>Detail Departemen</h1>
    <p><strong>Nama:</strong> {{ $department->name }}</p>
    <a href="{{ route('departments.edit', $department->id) }}" class="btn btn-primary">Edit</a>
    <form action="{{ route('departments.destroy', $department->id) }}" method="POST" style="display:inline;">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus?')">Hapus</button>
    </form>
    <a href="{{ route('departments.index') }}" class="btn btn-secondary">Kembali ke Daftar Departemen</a>
@endsection
