@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Edit Pegawai</h1>
        <<form action="{{ route('pegawai.update', $pegawai->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nama">Nama Pegawai:</label>
                <input type="text" name="nama" class="form-control" value="{{ $pegawai->nama }}">
            </div>
            <div class="form-group">
                <label for="jabatan">Jabatan:</label>
                <input type="text" name="jabatan" class="form-control" value="{{ $pegawai->jabatan }}">
            </div>
            <div class="form-group">
                <label for="umur">Umur:</label>
                <input type="number" name="umur" class="form-control" value="{{ $pegawai->umur }}">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <textarea name="alamat" class="form-control">{{ $pegawai->alamat }}</textarea>
            </div>
            <div class="form-group">
                <label for="department_id">Departemen:</label>
                <select name="department_id" class="form-control">
                    @foreach ($departments as $department)
                        <option value="{{ $department->id }}" {{ $pegawai->department_id == $department->id ? 'selected' : '' }}>{{ $department->name }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
        <a href="{{ route('pegawai.show', $pegawai->id) }}" class="btn btn-secondary">Batal</a>
    </div>
@endsection
