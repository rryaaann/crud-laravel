@extends('layouts.app')

@section('content')
    <h1>Daftar Pegawai</h1>
    <a href="{{ route('pegawai.create') }}" class="btn btn-primary mb-3">Tambah Pegawai</a>

    <ul class="list-group">
        @foreach ($pegawais as $pegawai)
            <li class="list-group-item">
                {{ $pegawai->nama }}
                @if ($pegawai->department)
                    - {{ $pegawai->department->name }}
                @else
                    - Belum memiliki departemen
                @endif
                <span class="float-right">
                    <a href="{{ route('pegawai.show', $pegawai->id) }}" class="btn btn-info btn-sm">Detail</a>
                    <a href="{{ route('pegawai.edit', $pegawai->id) }}" class="btn btn-primary btn-sm">Edit</a>
                </span>
            </li>
        @endforeach
    </ul>
@endsection
