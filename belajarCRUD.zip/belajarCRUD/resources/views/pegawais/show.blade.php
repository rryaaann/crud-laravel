@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detail Pegawai</h1>
        <div class="card">
            <div class="card-header">
                {{ $pegawai->nama }}
            </div>
            <div class="card-body">
                <p>Jabatan: {{ $pegawai->jabatan }}</p>
                <p>Umur: {{ $pegawai->umur }}</p>
                <p>Alamat: {{ $pegawai->alamat }}</p>
                @if ($pegawai->department)
                    <p>Department: {{ $pegawai->department->name }}</p>
                @else
                    <p>Department: Belum memiliki departemen</p>
                @endif
            </div>
            <div class="card-footer">
                <a href="{{ route('pegawai.edit', $pegawai->id) }}" class="btn btn-primary">Edit</a>
                <form action="{{ route('pegawai.destroy', $pegawai->id) }}" method="POST" class="d-inline">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus pegawai ini?')">Hapus</button>
                </form>
            </div>
        </div>
    </div>
@endsection
